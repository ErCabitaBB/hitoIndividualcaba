import java.util.Scanner;

public class dos {

	public static void main(String[] args) {
		Scanner scan = new Scanner(System.in);
		int input;
		String inputstr;
		String limpiascanner;
		double puntos=0;
		// TODO Auto-generated method stub
		System.out.println("¿Cuanto son 2 x 3?");
		input = scan.nextInt();
		if (input==6) {
			System.out.println("Respuesta correcta");
			puntos=puntos+1.0;
		} else {
			System.out.println("Respuesta incorrecta");
			puntos=puntos-0.5;
		}
		System.out.println("¿Es la tierra realmente esferica?");
		limpiascanner=scan.nextLine();
		inputstr = scan.nextLine();
		if (inputstr.toUpperCase().equals("NO")) {
			System.out.println("Respuesta correcta");
			puntos=puntos+1.0;
		} else {
			System.out.println("Respuesta incorrecta");
			puntos=puntos-0.5;
		}
		System.out.println("¿En que año se realizo el primer viaje a la luna?(4 digitos)");
		input = scan.nextInt();
		if (input==1969) {
			System.out.println("Respuesta correcta");
			puntos=puntos+1.0;
		} else {
			System.out.println("Respuesta incorrecta");
			puntos=puntos-0.5;
		}
		System.out.println("¿Cual es el pais mas grande del mundo?");
		limpiascanner=scan.nextLine();
		inputstr = scan.nextLine();
		if (inputstr.toUpperCase().equals("RUSIA")) {
			System.out.println("Respuesta correcta");
			puntos=puntos+1.0;
		} else {
			System.out.println("Respuesta incorrecta");
			puntos=puntos-0.5;
		}
		System.out.println("¿Cual es la capital de Italia?");
		inputstr = scan.nextLine();
		if (inputstr.toUpperCase().equals("ROMA")) {
			System.out.println("Respuesta correcta");
			puntos=puntos+1.0;
		} else {
			System.out.println("Respuesta incorrecta");
			puntos=puntos-0.5;
		}
		System.out.println("¿Es Washington.D.C la capital de Estados Unidos?");
		inputstr = scan.nextLine();
		if (inputstr.toUpperCase().equals("SI")) {
			System.out.println("Respuesta correcta");
			puntos=puntos+1.0;
		} else {
			System.out.println("Respuesta incorrecta");
			puntos=puntos-0.5;
		}
		System.out.println("¿Las arañas son insectos?");
		inputstr = scan.nextLine();
		if (inputstr.toUpperCase().equals("NO")) {
			System.out.println("Respuesta correcta");
			puntos=puntos+1.0;
		} else {
			System.out.println("Respuesta incorrecta");
			puntos=puntos-0.5;
		}
		System.out.println("¿Cual es la capital de España?");
		inputstr = scan.nextLine();
		if (inputstr.toUpperCase().equals("MADRID")) {
			System.out.println("Respuesta correcta");
			puntos=puntos+1.0;
		} else {
			System.out.println("Respuesta incorrecta");
			puntos=puntos-0.5;
		}
		System.out.println("¿Quien es el hombre mas rico del mundo?");
		inputstr = scan.nextLine();
		if (inputstr.toUpperCase().equals("ELON MUSK")) {
			System.out.println("Respuesta correcta");
			puntos=puntos+0.5;
		} else {
			System.out.println("Respuesta incorrecta");
			puntos=puntos-0.5;
		}
		System.out.println("¿En que año se inicio la segunda guerra mundial?");
		input = scan.nextInt();
		if (input==1939) {
			System.out.println("Respuesta correcta");
			puntos=puntos+1.0;
		} else {
			System.out.println("Respuesta incorrecta");
			puntos=puntos-0.5;
		}
		
		System.out.println("Total de puntos: "+puntos);
		if (puntos>4.5) {
			System.out.println("Enhorabuena, has aprobado");
		} else {
			System.out.println("Lo sentimos mucho, has suspendido");
		}
	}

}
