import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Scanner;

public class tres {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner scan = new Scanner(System.in);
		int input;
		String limpiascanner;
		
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
		} catch (ClassNotFoundException e) {
			System.out.println("No se ha encontrado el driver para MySQL");
			return;
		}
		System.out.println("Se ha cargado el Driver de MySQL");
		String cadenaConexion = "jdbc:mysql://localhost:3306/tienda";
		String user = "root";
		String pass = ""; 
		Connection con;
		try {
			con = DriverManager.getConnection(cadenaConexion, user, pass);
		} catch (SQLException e) {
			System.out.println("Error en la conexión con la BD");
			System.out.println(e.getMessage());
			return;
		}
		System.out.println("Se ha establecido la conexión con la Base de datos");
		
		System.out.println("---------------------");
		System.out.println("¿Que quieres hacer?");
		System.out.println("1. insertar producto");
		System.out.println("2. eliminar producto productos");
		System.out.println("3. actualizar productos");
		System.out.println("4. ver productos");
		
		input=scan.nextInt();
		
		switch (input) {
		case 1:
			try {
				Statement sentencia = con.createStatement(ResultSet.TYPE_SCROLL_SENSITIVE, ResultSet.CONCUR_UPDATABLE);
				ResultSet rs = sentencia.executeQuery("SELECT * FROM productos");
				System.out.println("Inserta el nombre del producto");
				limpiascanner=scan.nextLine();
				String nombre=scan.nextLine();
				System.out.println("Inserta la fecha de envasado (dd/mm/aaaa)");
				String fechaEnv=scan.nextLine();
				System.out.println("Cuantas unidades hay");
				int unidades=scan.nextInt();
				System.out.println("Cuanto cuesta el producto (int)");
				int precio = scan.nextInt();
				rs.moveToInsertRow(); 
				rs.updateString("nombre", nombre); 
				rs.updateString("fechaEnvasado", fechaEnv);
				rs.updateInt("unidades", unidades); 
				rs.updateInt("precio", precio); 
				rs.updateBoolean("disponible", true); 
				rs.insertRow(); 
				System.out.println("Se ha añadido correctamente el producto");

			} catch (SQLException e) {
				System.out.println("Error al añadir el nuevo producto");
				System.out.println(e.getMessage());
			}
			break;
		case 2:
			try {
				System.out.println("Que producto desea eliminar (id)");
				input=scan.nextInt();
				Statement sentencia = con.createStatement(ResultSet.TYPE_SCROLL_SENSITIVE, ResultSet.CONCUR_UPDATABLE);
				ResultSet rs = sentencia.executeQuery("SELECT * FROM productos WHERE idProducto = '"+input+"'");
				boolean existe = rs.next();
				if (existe) {
					rs.deleteRow();
					System.out.println("Se ha eliminado correctamente el producto");
				}
			} catch (SQLException e) {
				System.out.println("Error al eliminar el producto");
				System.out.println(e.getMessage());
			}
			break;
		case 3: 
			try {
				System.out.println("Que producto desea actualizar (id), solo se podra modificar el precio y las unidades que dispone este producto");
				input=scan.nextInt();
				System.out.println("Que precio desearia establecer(int)");
				int precio=scan.nextInt();
				System.out.println("Cuantas unidades hay del producto");
				int unidades=scan.nextInt();
				Statement sentencia = con.createStatement(ResultSet.TYPE_SCROLL_SENSITIVE, ResultSet.CONCUR_UPDATABLE);
				ResultSet rs = sentencia.executeQuery("SELECT * FROM productos WHERE idProducto = '"+input+"'");
				boolean existe = rs.next();
				if (existe) {
					rs.updateInt("precio", precio);
					rs.updateInt("unidades", unidades);
					rs.updateRow();
					System.out.println("Se ha actualizado correctamente el producto");
				}
			} catch (SQLException e) {
				System.out.println("Error al actualizar los datos del producto");
				System.out.println(e.getMessage());
			}
			break;
		case 4:
			try {
				Statement sentencia = con.createStatement();
				ResultSet rs = sentencia.executeQuery("select * from productos");
				while (rs.next()) {
					System.out.print(rs.getInt("idProducto"));
					System.out.print(" - ");
					System.out.print(rs.getString("nombre"));
					System.out.print(" - "); 
					System.out.print(rs.getString("fechaEnvasado"));
					System.out.print(" - "); 
					System.out.print(rs.getInt("unidades"));
					System.out.print(" - "); 
					System.out.print(rs.getDouble("precio"));
					System.out.print(" - "); 
					System.out.print(rs.getBoolean("disponible"));
					System.out.println(); // Retorno de carro
				}
			} catch (SQLException e) {
				System.out.println("Error al realizar el listado de producto");
				System.out.println(e.getMessage());
			}
			break;
		default:
			break;
		}
		
		
		try {
			con.close();
		} catch (SQLException e1) {
			System.out.println("No se ha podido cerrar la conexión con la BD");
			System.out.println(e1.getMessage());
			return;
		}
		System.out.println("Se ha cerrado la base de datos");

	
	}
}
