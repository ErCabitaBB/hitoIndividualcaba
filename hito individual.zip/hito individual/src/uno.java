public class uno {
	int numero;
	String letra;
	
	public uno(int numero, String letra) {
		super();
		this.numero = numero;
		this.letra = letra;
	}
	
	public uno() {
		super();
		this.numero = 1;
		this.letra = "c";
	}

	@Override
	public String toString() {
		return "uno [numero=" + numero + ", letra=" + letra + "]";
	}
	
	
}
